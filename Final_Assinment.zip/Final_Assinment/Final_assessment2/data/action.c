Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.5");

	web_url("remote-settings.content-signature.mozilla.org-2024-08-29-13-50-59.chain", 
		"URL=https://content-signature-2.cdn.mozilla.net/chains/remote-settings.content-signature.mozilla.org-2024-08-29-13-50-59.chain", 
		"TargetFrame=", 
		"Resource=1", 
		"Referer=", 
		"Snapshot=t2.inf", 
		LAST);

	web_url("banking", 
		"URL=http://localhost/banking", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_websocket_send("ID=0", 
		"Buffer={\"messageType\":\"hello\",\"broadcasts\":{\"remote-settings/monitor_changes\":\"\\\"1722394630668\\\"\"},\"use_webpush\":true}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive0*/

	lr_think_time(15);

	lr_start_transaction("T02_Staff_Login");

	web_url("Staff Login", 
		"URL=http://localhost/banking/staff_login.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../favicon.ico", ENDITEM, 
		LAST);

	web_submit_data("staff_login.php", 
		"Action=http://localhost/banking/staff_login.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/staff_login.php", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=staff_id", "Value=210001", ENDITEM, 
		"Name=password", "Value=password", ENDITEM, 
		"Name=staff_login-btn", "Value=LOGIN", ENDITEM, 
		EXTRARES, 
		"Url=img/customers/No_image.jpg", "Referer=http://localhost/banking/staff_profile.php", ENDITEM, 
		LAST);

	lr_start_transaction("T03_Click_Login");

	lr_start_transaction("T04_Click_Approve_pending_Acc");

	web_submit_data("staff_profile.php", 
		"Action=http://localhost/banking/staff_profile.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/staff_profile.php", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=apprvac", "Value=Approve Pending Account", ENDITEM, 
		LAST);

	lr_think_time(34);

	lr_start_transaction("T05_Search_Application_number");

	web_submit_data("pending_customers.php", 
		"Action=http://localhost/banking/pending_customers.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/pending_customers.php", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=application_no", "Value=742267772", ENDITEM, 
		"Name=search_application", "Value=Search", ENDITEM, 
		LAST);

	lr_think_time(22);

	lr_start_transaction("T06_Click_Approve");

	web_submit_data("pending_customers.php_2", 
		"Action=http://localhost/banking/pending_customers.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/pending_customers.php", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=approve_cust", "Value=Approve", ENDITEM, 
		LAST);

	lr_start_transaction("T07_Click_OK");

	lr_start_transaction("T08_Logout");

	web_url("staff_logout.php", 
		"URL=http://localhost/banking/staff_logout.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/pending_customers.php", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}