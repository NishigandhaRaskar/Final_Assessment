Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.5");

	web_url("remote-settings.content-signature.mozilla.org-2024-08-29-13-50-59.chain", 
		"URL=https://content-signature-2.cdn.mozilla.net/chains/remote-settings.content-signature.mozilla.org-2024-08-29-13-50-59.chain", 
		"TargetFrame=", 
		"Resource=1", 
		"Referer=", 
		"Snapshot=t2.inf", 
		LAST);

	
		lr_start_transaction("SC02_Banking_T04_Click_Approve_pending_Acc");
		
		web_reg_find("text=Staff Page","SaveCount=Login_Successful", LAST);
		
		web_submit_data("staff_profile.php_2", 
		"Action=http://localhost/banking/staff_profile.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/staff_profile.php", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=apprvac", "Value=Approve Pending Account", ENDITEM, 
		LAST);
		
	
	lr_end_transaction("SC02_Banking_T04_Click_Approve_pending_Acc",LR_AUTO);

	lr_think_time(34);

	lr_start_transaction("SC02_Banking_T05_Search_Application_number");
	
	web_reg_find("text=application_no","SaveCount=App_No", LAST);
	
	web_reg_save_param("C_Details",
		"LB=<td>",
		"RB=</td",
		//"NotFound=ERROR",
		"ORD=ALL",
		LAST);
	
	
	web_submit_data("pending_customers.php", 
		"Action=http://localhost/banking/pending_customers.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/pending_customers.php", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=application_no", "Value={P_Application_No}", ENDITEM, 
		"Name=search_application", "Value=Search", ENDITEM, 
		LAST);
	
	lr_end_transaction("SC02_Banking_T05_Search_Application_number",LR_AUTO);

	lr_think_time(22);

	lr_start_transaction("SC02_Banking_T06_Click_Approve");
	
	web_reg_find("text=Approve","SaveCount=Approval", LAST);
	
	web_reg_save_param("C_AccountNumber",
		"LB=Account no :",
		"RB=\\",
		//"NotFound=ERROR",
		LAST);

	web_submit_data("pending_customers.php_2",
		"Action=http://localhost/banking/pending_customers.php",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=http://localhost/banking/pending_customers.php",
		"Snapshot=t8.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=approve_cust", "Value=Approve", ENDITEM,
		LAST);
	lr_end_transaction("SC02_Banking_T06_Click_Approve",LR_AUTO);

	//lr_start_transaction("T07_Click_OK");

	
	return 0;
}