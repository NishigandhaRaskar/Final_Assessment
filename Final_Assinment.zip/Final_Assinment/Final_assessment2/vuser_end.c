vuser_end()
{
	long file;
	lr_start_transaction("SC02_Banking_T07_Logout");

	web_url("staff_logout.php", 
		"URL=http://localhost/banking/staff_logout.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/pending_customers.php", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);
	
	lr_end_transaction("SC02_Banking_T07_Logout",LR_AUTO);
	
	file = fopen("C:\\Users\\Administrator\\Documents\\VuGen\\Scripts\\Final_Ass\\VerifiedAccounts.txt","a+");
        fprintf(file,"%s",lr_eval_string("Account_Number:{C_AccountNumber} \n"));
        fclose(file);
        
    file = fopen("C:\\Users\\Administrator\\Documents\\VuGen\\Scripts\\Final_Ass\\New Accounts.txt","a+");
          // fopen("C:\\Users\\Administrator\\Documents\\VuGen\\Scripts\\Final_Ass\\Applications.txt");
        fprintf(file,"%s",lr_eval_string("Account_Number:{C_AccountNumber}, Detailes: {C_Details} \n"));
        fclose(file);    

	return 0;
}
