Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.5");

	web_url("banking", 
		"URL=http://localhost/banking", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_websocket_send("ID=0", 
		"Buffer={\"messageType\":\"hello\",\"broadcasts\":{\"remote-settings/monitor_changes\":\"\\\"1722394630668\\\"\"},\"use_webpush\":true}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive0*/

	lr_think_time(31);

	lr_start_transaction("T02_Click_");

	web_url("Open Account", 
		"URL=http://localhost/banking/customer_reg_form.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../favicon.ico", ENDITEM, 
		LAST);

	lr_start_transaction("T03_Fill_Account_Opening_Form");

	lr_start_transaction("Click_Submit");

	web_submit_data("customer_reg_form.php", 
		"Action=http://localhost/banking/customer_reg_form.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/customer_reg_form.php", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=name", "Value=Nishigandha Raskar", ENDITEM, 
		"Name=gender", "Value=Female", ENDITEM, 
		"Name=mobile", "Value=1234567898", ENDITEM, 
		"Name=email", "Value=nish@gmail.com", ENDITEM, 
		"Name=landline", "Value=123456", ENDITEM, 
		"Name=dob", "Value=2000-12-04", ENDITEM, 
		"Name=pan_no", "Value=RTOH12345", ENDITEM, 
		"Name=citizenship", "Value=12345", ENDITEM, 
		"Name=homeaddrs", "Value=satara", ENDITEM, 
		"Name=officeaddrs", "Value=pune", ENDITEM, 
		"Name=country", "Value=US", ENDITEM, 
		"Name=state", "Value=Florida", ENDITEM, 
		"Name=city", "Value=Fresno", ENDITEM, 
		"Name=pin", "Value=415521", ENDITEM, 
		"Name=arealoc", "Value=ABC", ENDITEM, 
		"Name=nominee_name", "Value=NA", ENDITEM, 
		"Name=nominee_ac_no", "Value=123456789", ENDITEM, 
		"Name=acctype", "Value=Saving", ENDITEM, 
		"Name=submit", "Value=Submit", ENDITEM, 
		LAST);

	lr_think_time(27);

	lr_start_transaction("Click_confirm");

	web_submit_data("cust_regfrm_confirm.php", 
		"Action=http://localhost/banking/cust_regfrm_confirm.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/cust_regfrm_confirm.php", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=cnfrm-submit", "Value=Confirm", ENDITEM, 
		LAST);

	lr_think_time(14);

	lr_start_transaction("Click_OK");

	web_url("Home", 
		"URL=http://localhost/banking/index.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/cust_regfrm_confirm.php", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}